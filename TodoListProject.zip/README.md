# Interactive To-Do List

This is a simple interactive To-Do List web application built with HTML, CSS, and JavaScript.

Features:
- Add tasks
- Mark tasks as completed by clicking
- Remove tasks with a delete button